import 'package:flutter/material.dart';

class MyTextStyle {
  static TextStyle circular() {
    return TextStyle(
      fontFamily: 'circular',
    );
  }
}
