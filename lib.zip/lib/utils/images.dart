var logo = "assets/images/logo.png";
var pic1 = "assets/images/pic1.jpg";
var pic2 = "assets/images/pic2.png";
var technisionIcon = "assets/images/technisionIcon.png";
var vehicleIcon = "assets/images/vehicleIcon.png";
var workshopIcon = "assets/images/workshopIcon.png";
var userNamePic = "assets/images/userNamePic.png";
var drawerAboutIcon = "assets/images/drawerAboutIcon.png";
var drawerCarIcon = "assets/images/drawerCarIcon.png";
var drawerInviteIcon = "assets/images/drawerInviteIcon.png";
var drawerPaymentIcon = "assets/images/drawerPaymentIcon.png";
var drawerSettingIcon = "assets/images/drawerSettingIcon.png";
var drawerTermsIcon = "assets/images/drawerTermsIcon.png";
var editIcon = "assets/images/editIcon.png";
var warrantyIcon = "assets/images/warrantyIcon.png";
var carIcon = "assets/images/directions-car-outlined-24px.png";


var homeIcon = "assets/images/home.png";
var listIcon = "assets/images/receipt-check.png";
var plusIcon = "assets/images/plus.png";
var notificationImage = "assets/images/notification.png";

var myCarIcon = "assets/images/directions-car-outlined-24px.png";
var phoneIcon = "assets/images/phone.png";