class Finals {
  static String USER_LOGGED_IN_OR_NOT="UserLoggedInOrNot";
  static String USER_EMAIL="userEmail";
  static String USER_TOKEN="token";
  static String USER_REFRESH_TOKEN="refreshToken";
  static String USER_ID="userID";
  static String USER_NAME="userNAme";
  static String USER_PHONE="userPhone";
  static String USER_TYPE_ID="userTypeID";
  static String USER_NOTIFICATION="notifications";
  static String USER_Language="Language";
  static String USER_COUPON="USER_COUPON";


}