import 'languages.dart';

class LanguageAr extends Languages {

  @override
  String get appName => "متعدد اللغات";

  @override
  String get labelWelcome => "أهلا بك";

  @override
  String get labelSelectLanguage => "اختار اللغة";

  @override
  String get labelInfo => "هذا هو التطبيق التجريبي متعدد اللغات";

}
